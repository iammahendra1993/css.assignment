import React from 'react';

const UserHome = () => {
  return <div>Welcome to the User Home Page</div>;
};

export default UserHome;
