import React from 'react';

const AdminHome = () => {
  return <div>Welcome to the Admin Home Page</div>;
};

export default AdminHome;
